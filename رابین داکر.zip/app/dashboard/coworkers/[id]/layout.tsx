export default function CoworkerLayout({
    children,
}: {
    children: React.ReactNode
}) {
    return children;
}
