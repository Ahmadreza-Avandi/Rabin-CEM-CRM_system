export default function CEMSettingsPage() {
    return (
        <div className="container mx-auto p-6">
            <h1 className="text-2xl font-bold mb-4">تنظیمات بخش تجربه مشتری (CEM)</h1>
            <p>این صفحه در حال توسعه است...</p>
        </div>
    );
}
